// Variáveis globais
let currentUser = null;
let timerInterval;
let isTimerRunning = false;
let currentTime = 300; // 5 minutos em segundos
let totalTime = 300;

// Transição da tela inicial para o conteúdo
window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.getElementById("startScreen").classList.add("hidden");
    setTimeout(() => {
      document.getElementById("mainContent").style.display = "block";
      animateElements();
    }, 1000); // tempo da transição
  }, 2500); // tempo que a tela inicial fica visível
});

function animateElements() {
  const fadeElements = document.querySelectorAll(".fade-in");
  const scaleElements = document.querySelectorAll(".scale-in");

  fadeElements.forEach((el, index) => {
    setTimeout(() => el.classList.add("visible"), index * 200);
  });
  scaleElements.forEach((el, index) => {
    setTimeout(() => el.classList.add("visible"), index * 300);
  });
}

function handleLogin() {
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  if (email && password) {
    alert(`Login realizado com sucesso para ${email}`);
  } else {
    alert("Por favor, preencha o e-mail e a senha.");
  }
}

// Função para simular login com Google (para demonstração)
function handleGoogleSignIn() {
  // Simulação de dados do usuário para demonstração
  const userData = {
    name: "Usuário Demo",
    email: "usuario@demo.com",
    picture: "https://via.placeholder.com/40x40/4285F4/ffffff?text=U",
  };

  showUserProfile(userData);
}

// Função para exibir perfil do usuário após login
function showUserProfile(userData) {
  currentUser = userData;

  // Atualizar todas as áreas de login em todas as páginas
  const loginAreas = [
    "login-area-limites",
    "login-area-tempo",
    "login-area-saude",
    "login-area-relacionamentos",
  ];
  const userProfiles = [
    "user-profile-limites",
    "user-profile-tempo",
    "user-profile-saude",
    "user-profile-relacionamentos",
  ];
  const traditionalLogins = [
    "traditional-login-limites",
    "traditional-login-tempo",
    "traditional-login-saude",
    "traditional-login-relacionamentos",
  ];
  const userPictures = [
    "user-picture-limites",
    "user-picture-tempo",
    "user-picture-saude",
    "user-picture-relacionamentos",
  ];
  const userNames = [
    "user-name-limites",
    "user-name-tempo",
    "user-name-saude",
    "user-name-relacionamentos",
  ];

  // Ocultar botões de login e mostrar perfis
  traditionalLogins.forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.classList.add("hidden");
  });

  userProfiles.forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.classList.remove("hidden");
  });

  // Atualizar informações do usuário
  userPictures.forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.src = userData.picture;
  });

  userNames.forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.textContent = userData.name;
  });
}

// Função para fazer logout
function handleSignOut() {
  currentUser = null;

  // Restaurar estado inicial de login em todas as páginas
  const userProfiles = [
    "user-profile-limites",
    "user-profile-tempo",
    "user-profile-saude",
    "user-profile-relacionamentos",
  ];
  const traditionalLogins = [
    "traditional-login-limites",
    "traditional-login-tempo",
    "traditional-login-saude",
    "traditional-login-relacionamentos",
  ];

  userProfiles.forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.classList.add("hidden");
  });

  traditionalLogins.forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.classList.remove("hidden");
  });
}

// Funções de navegação
function backToMain() {
  window.location.href = "index.html";
}

function showMindfulnessPage() {
  window.location.href = "mindfulness.html";
}

function showLimitesDigitais() {
  window.location.href = "limites-digitais.html";
}

function showTempoTela() {
  window.location.href = "tempo-tela.html";
}

function showSaudeMental() {
  window.location.href = "saude-mental.html";
}

function showRelacionamentos() {
  window.location.href = "relacionamentos.html";
}

function showChatPage() {
  window.location.href = "chat.html";
}

function showComunidade() {
  window.location.href = "comunidade.html";
}

function startChat() {
  // Rola a página até o chat container
  document.getElementById("chat-container").scrollIntoView({
    behavior: "smooth",
  });
}

function loadChatScript() {
  // Cria o elemento script
  const script = document.createElement("script");
  script.type = "module";
  script.innerHTML = `
            import Chatbox from 'https://cdn.jsdelivr.net/npm/@chatvolt/embeds@1.1.6/dist/chatbox/index.js';

            Chatbox.initStandard({
                agentId: 'cmdvxip8s0h8p1kvu08t5h6ew', // Seu agente da Chatvolt

                contact: {
                    firstName: '${
                      currentUser ? currentUser.name : "Visitante"
                    }',
                    lastName: '',
                    email: '${currentUser ? currentUser.email : ""}',
                    phoneNumber: '',
                },

                interface: {
                    initialMessages: [
                        'Olá! 👋 Seja bem-vindo à Mente Conectada.',
                        'Como posso ajudar você hoje?',
                    ],
                },

                context: 'O usuário está acessando o site Mente Conectada e procura apoio emocional ou orientação sobre nossos serviços online.',
            });
        `;

  // Adiciona o script ao documento
  document.body.appendChild(script);
}

// Função para aceitar o desafio
function acceptChallenge() {
  alert(
    "Parabéns! Você aceitou o Desafio dos 7 Dias! Comece hoje mesmo e transforme sua relação com a tecnologia. Lembre-se: pequenos passos levam a grandes mudanças!"
  );
}

// Funções do Timer de Meditação
function setTimer(minutes) {
  currentTime = minutes * 60;
  totalTime = minutes * 60;
  updateTimerDisplay();
  updateProgressRing();

  // Reset timer se estiver rodando
  if (isTimerRunning) {
    clearInterval(timerInterval);
    isTimerRunning = false;
    document.getElementById("timer-btn").innerHTML =
      '<i class="fas fa-play mr-2"></i>Iniciar';
  }
}

function toggleTimer() {
  if (isTimerRunning) {
    // Pausar timer
    clearInterval(timerInterval);
    isTimerRunning = false;
    document.getElementById("timer-btn").innerHTML =
      '<i class="fas fa-play mr-2"></i>Continuar';
  } else {
    // Iniciar timer
    isTimerRunning = true;
    document.getElementById("timer-btn").innerHTML =
      '<i class="fas fa-pause mr-2"></i>Pausar';

    timerInterval = setInterval(() => {
      currentTime--;
      updateTimerDisplay();
      updateProgressRing();

      if (currentTime <= 0) {
        clearInterval(timerInterval);
        isTimerRunning = false;
        document.getElementById("timer-btn").innerHTML =
          '<i class="fas fa-play mr-2"></i>Iniciar';
        alert("🧘‍♀️ Sessão de meditação concluída! Parabéns!");
        currentTime = totalTime;
        updateTimerDisplay();
        updateProgressRing();
      }
    }, 1000);
  }
}

function updateTimerDisplay() {
  const minutes = Math.floor(currentTime / 60);
  const seconds = currentTime % 60;
  document.getElementById("timer-display").textContent = `${minutes
    .toString()
    .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

function updateProgressRing() {
  const progress = (totalTime - currentTime) / totalTime;
  const circumference = 2 * Math.PI * 45;
  const offset = circumference - progress * circumference;
  document.getElementById("progress-circle").style.strokeDashoffset =
    offset;
}

function startMeditation() {
  scrollToSection("praticas");
  setTimeout(() => {
    setTimer(5);
    toggleTimer();
  }, 1000);
}

function scrollToSection(sectionId) {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: "smooth" });
  }
}

// Funções dos modais (simuladas)
function openMeditationModal() {
  alert(
    "🧘‍♀️ Abrindo sessão de meditação guiada... Em breve você terá acesso a exercícios completos de respiração e mindfulness!"
  );
}

function openDigitalLimitsModal() {
  alert(
    "📱 Configurando limites digitais... Em breve você poderá definir metas personalizadas de tempo de tela!"
  );
}

function openCommunityModal() {
  alert(
    "👥 Redirecionando para a comunidade... Em breve você poderá participar de grupos de apoio e desafios!"
  );
}

// Função para inicializar o chat
function initChat() {
  document.getElementById("chat-container").classList.remove("hidden");
  document
    .getElementById("chat-container")
    .scrollIntoView({ behavior: "smooth" });

  // Adiciona mensagem inicial da IA
  addMessage(
    "assistant",
    "Olá! 👋 Sou o Assistente de Saúde Mental da Mente Conectada. Como posso te ajudar hoje?"
  );
}

// Função para adicionar mensagens ao chat
function addMessage(role, content) {
  const messagesContainer = document.getElementById("chat-messages");
  const messageDiv = document.createElement("div");

  if (role === "assistant") {
    messageDiv.className = "flex items-start";
    messageDiv.innerHTML = `
      <div class="bg-blue-100 rounded-lg p-3 max-w-[80%]">
        <p class="text-gray-800">${content}</p>
      </div>
    `;
  } else {
    messageDiv.className = "flex items-start justify-end";
    messageDiv.innerHTML = `
      <div class="bg-blue-600 text-white rounded-lg p-3 max-w-[80%]">
        <p>${content}</p>
      </div>
    `;
  }

  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Função para enviar mensagem
function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();

  if (message) {
    // Adiciona mensagem do usuário
    addMessage("user", message);
    input.value = "";

    // Simula resposta da IA (em uma implementação real, você faria uma chamada API)
    setTimeout(() => {
      const responses = [
        "Entendo como você se sente. Poderia me contar mais sobre isso?",
        "Você não está sozinho(a) nessa situação. Como isso tem afetado seu dia a dia?",
        "Isso parece desafiador. O que você acha que poderia te ajudar a lidar com essa situação?",
        "Agradeço por compartilhar isso comigo. Vamos pensar juntos em estratégias para melhorar como você se sente.",
      ];
      const randomResponse =
        responses[Math.floor(Math.random() * responses.length)];
      addMessage("assistant", randomResponse);
    }, 1000);
  }
}

// Permite enviar mensagem com Enter
document.addEventListener("DOMContentLoaded", function() {
  const userInput = document.getElementById("user-input");
  if (userInput) {
    userInput.addEventListener("keypress", function (e) {
      if (e.key === "Enter") {
        sendMessage();
      }
    });
  }
});

// Carrega o script do chat quando necessário
window.addEventListener("DOMContentLoaded", () => {
  // Carrega o script do chat apenas quando a página é acessada
  if (window.location.pathname.includes('chat.html') && !window.chatLoaded) {
    loadChatScript();
    window.chatLoaded = true;
  }
});

